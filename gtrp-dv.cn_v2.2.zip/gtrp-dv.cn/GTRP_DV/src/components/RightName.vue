<template>
  <footer>
    <div class="record">
      <span>Copyright©2020-2024 Ahxin  |  <a href="https://space.bilibili.com/410725984" target="_blank">B站云上贵猪</a></span>
      <span class="divider">&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</span>
      <img src="https://a-hxin.cn/sol/Img/gongan.png" height="18" width="18" alt="公安备案图标">
      <a href="http://www.beian.gov.cn/portal/registerSystemInfo?recordcode=44011702000808" target="_blank" rel="nofollow" title="公安部备案号">
        粤公网安备44011702000808号
      </a>
      <span class="divider">&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;</span>
      <img src="https://a-hxin.cn/sol/Img/ICP.png" height="18" width="18" alt="公安备案图标">
      <a href="https://beian.miit.gov.cn/" target="_blank" rel="nofollow" title="工业和信息化部备案号">
        粤ICP备2021019148号-1
      </a>
    </div>
  </footer>
</template>

<style scoped>
.record{
  width: 100%;
  height: 8vh;
  margin-top: 1.5rem;
  background-color: rgba(255, 212, 101, 0.59);
  backdrop-filter: blur(10px);
  line-height: 8vh;
  text-align: center;
  font-size: 1.3rem;
  border-radius: 20px 20px 0 0;

}

</style>


<script setup>
</script>